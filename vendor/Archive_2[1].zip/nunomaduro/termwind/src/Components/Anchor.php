<?php

declare(strict_types=1);

namespace Termwind\Components;

final class Anchor extends Element
{
}
